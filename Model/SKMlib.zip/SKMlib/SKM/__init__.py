# -*- coding: utf-8 -*-
"""
Created on Fri Nov 22 16:03:17 2019

__init.py__ 
@author: laia.domingo.colomer
"""


from curve_new_data import get_predicted_curves


